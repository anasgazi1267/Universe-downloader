export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  try {
    const { url, format } = req.body;

    if (!url) {
      return res.status(400).json({ error: "URL required" });
    }

    const apiRes = await fetch("https://api.cobalt.tools/api/json", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json"
      },
      body: JSON.stringify({
        url: url,
        vCodec: format === "mp3" ? "none" : "h264",
        aFormat: format === "mp3" ? "mp3" : "aac"
      })
    });

    const data = await apiRes.json();
    return res.status(200).json(data);

  } catch (err) {
    return res.status(500).json({ error: "Server failed" });
  }
}
